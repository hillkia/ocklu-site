---
name: ulang-konten
description: Ubah SATU konten sumber (link YouTube, artikel, transkrip, atau catatan) menjadi 5 konten siap pakai - blog, newsletter, caption Instagram, post LinkedIn, dan pesan WhatsApp broadcast - dalam gaya merek pemilik. Pakai saat diminta "repurpose", "ulang konten", "jadikan banyak konten", atau diberi link video untuk dijadikan postingan.
---

# Ulang Konten 1 → 5 (skill induk)

## Masukan
Link YouTube/artikel, berkas transkrip, atau teks. Untuk link, ambil isinya dengan alat web/scraper yang tersedia (mis. Firecrawl). Kalau tidak bisa diambil, minta pemilik menempel transkrip — **jangan menebak isi video dari judulnya**.

## Langkah
1. Baca `CLAUDE.md` di folder kerja (identitas merek, nada, larangan).
2. Ringkas sumber jadi: 1 ide utama, 3-5 poin pendukung, 1 kutipan/angka asli (kalau ada), 1 ajakan.
3. Jalankan skill anak berurutan, masing-masing simpan berkasnya:
   - `blog` → `konten/`
   - `newsletter` → `email/`
   - `caption-ig` → `sosmed/`
   - `linkedin` → `sosmed/`
   - Pesan WA broadcast (≤60 kata, 1 tautan, tanpa huruf kapital semua) → `sosmed/`
4. Semua angka/klaim harus ada di sumber. Klaim yang tidak ada di sumber dihapus.
5. Laporkan daftar 5 berkas + 1 kalimat ide utama.
