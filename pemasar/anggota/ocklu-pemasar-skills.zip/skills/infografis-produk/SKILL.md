---
name: infografis-produk
description: Dari link produk (Shopee, Tokopedia, Amazon, atau situs toko), ambil spesifikasi asli lalu buat konsep dan prompt gambar infografis produk untuk listing/Instagram story. Pakai saat diminta "infografis produk", "gambar listing", atau diberi link produk.
---

# Infografis Produk
1. Ambil halaman produk dengan alat web/scraper. Kalau gagal, minta pemilik menempel deskripsi — jangan menebak spesifikasi.
2. Tampilkan 6-8 fitur/spesifikasi yang ditemukan; minta pemilik memilih 3-5.
3. Tanyakan rasio: persegi 1:1 (feed/listing) atau tinggi 9:16 (story).
4. Tulis: judul ≤5 kata, 3-5 label fitur (≤4 kata + angka asli), tata letak, palet warna dari merek.
5. Kalau ada konektor generator gambar (mis. Higgsfield), buat gambarnya; kalau tidak, simpan prompt siap tempel.
6. Simpan ke `aset/infografis-slug.md` (+ gambar bila ada).
- Setiap angka harus berasal dari halaman produk.
