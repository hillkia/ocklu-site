---
name: caption-ig
description: Tulis caption Instagram/TikTok plus ide slide carousel. Pakai saat diminta "caption", "post IG", "carousel", atau dipanggil oleh skill ulang-konten.
---

# Caption IG / TikTok
- Baris pertama = kait ≤8 kata (bikin berhenti scroll), tanpa clickbait palsu.
- Badan 3-6 baris pendek, 1 ajakan jelas (mis. "Komen PANDUAN, kami kirim linknya").
- 5-10 tagar relevan (campur besar & niche, Bahasa Indonesia bila audiens lokal).
- Tambahkan rencana carousel 5-7 slide: teks tiap slide ≤15 kata.
- Simpan ke `sosmed/AAAA-BB-HH-ig-slug.md`.
