---
name: audit-ai-seo
description: Audit keterlihatan situs di Google dan di jawaban AI (ChatGPT, Claude, Gemini) - kata kunci yang layak dimiliki, celah pesaing, perbaikan judul/meta siap tempel. Pakai saat diminta "audit SEO", "AI SEO", "kenapa tidak muncul di ChatGPT", atau diberi URL situs untuk dianalisis.
---

# Audit AI-SEO
1. Ambil halaman depan + 3-5 halaman penting situs (alat web/scraper). Catat judul, meta, H1, isi utama.
2. Kalau ada konektor data SEO (mis. Semrush), ambil volume & tingkat kesulitan kata kunci. Kalau tidak ada, tandai angka sebagai **"perkiraan, belum diukur"** — jangan mengarang volume.
3. Tentukan:
   - 3 kata kunci "milik kita" (relevan, persaingan rendah).
   - 3 kata kunci besar untuk jangka panjang.
   - 2-3 pesaing yang muncul, dan apa yang mereka lakukan lebih baik.
4. Uji keterlihatan AI: tanyakan 5 pertanyaan pembeli ke model yang tersedia; catat apakah merek disebut. (Bila ada OCKLU AIRANK, pakai hasilnya.)
5. Keluarkan perbaikan siap tempel: judul (≤60), meta (≤155), H1, 1 paragraf "siapa kami & untuk siapa" yang jelas, ide 3 artikel.
6. Simpan `laporan/audit-ai-seo-domain.md`. Bedakan jelas: **diukur** vs **perkiraan**.
