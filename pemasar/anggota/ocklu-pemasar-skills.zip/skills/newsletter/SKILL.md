---
name: newsletter
description: Tulis newsletter email pendek dalam gaya merek pemilik. Pakai saat diminta "newsletter", "email ke list", atau dipanggil oleh skill ulang-konten.
---

# Newsletter
- Kalau ada `suara-email.md`, pakai sapaan & penutupnya.
- Subjek ≤7 kata + teks pratinjau ≤90 karakter.
- Isi 150-300 kata: 1 cerita/ide, 3 poin, 1 tautan ajakan. Paragraf ≤3 baris.
- Simpan ke `email/AAAA-BB-HH-newsletter-slug.md`. Tidak dikirim otomatis.
