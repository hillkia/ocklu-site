---
name: pelacak-outlier
description: Lacak konten pesaing atau konten sendiri (YouTube, TikTok, IG, blog) dan temukan "outlier" - konten yang performanya jauh di atas biasanya - untuk ide konten berikutnya. Pakai saat diminta "lacak pesaing", "cari ide konten yang terbukti", "outlier", atau "video mana yang meledak".
---

# Pelacak Outlier

## Rumus
`skor_outlier = views_konten ÷ median(views 20 konten terakhir channel yang sama)`
- ≥3.0 = outlier kuat, 1.5-3.0 = di atas rata-rata, <1.5 = biasa.
- Butuh minimal 8 konten per channel; kurang dari itu tulis "data tipis" dan jangan beri skor.

## Langkah
1. Minta daftar channel/akun (3-10).
2. Ambil judul, tanggal, views (dan like/komentar bila ada) dengan alat web/scraper/API yang tersedia. Jangan mengisi angka kosong dengan tebakan.
3. Hitung skor per konten; urutkan.
4. Untuk 5 outlier teratas: tulis kenapa kemungkinan berhasil (kait judul, topik, format) dan 1 ide versi kita.
5. Simpan tabel ke `laporan/outlier-AAAA-BB-HH.csv` + ringkasan `.md`. Kalau ada database (mis. Supabase), simpan juga agar bisa dibuat dasbor/jadwal harian.
