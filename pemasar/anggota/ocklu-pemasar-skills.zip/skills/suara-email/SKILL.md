---
name: suara-email
description: Pelajari gaya menulis email pemilik dari 20-35 email TERKIRIM di Gmail, lalu tulis DRAF email baru dengan gaya itu. Pakai saat diminta "tulis email", "balas email", "draf ajakan", "email ke prospek", atau "pelajari gaya email saya".
---

# Suara Email

## Aturan keras
- **Hanya draf.** Jangan pernah mengirim, membalas langsung, mengubah, atau menghapus email. Hasil akhir = draf di Gmail atau berkas `email/*.md`.
- Jangan mengarang fakta, angka, klien, atau testimoni. Kalau data kurang, tulis `[ISI: ...]`.

## Langkah pertama kali (belajar gaya)
1. Lewat konektor Gmail, baca 20-35 email di folder **Terkirim** (lewati email otomatis/notifikasi).
2. Catat ke `suara-email.md` di folder kerja:
   - Sapaan pembuka yang paling sering (mis. "Halo Pak Budi," / "Hi Sarah,").
   - Panjang rata-rata (kalimat & paragraf), bahasa (ID/EN/campur), tingkat formal.
   - Kata/frasa khas yang sering dipakai; kata yang TIDAK pernah dipakai.
   - Penutup & tanda tangan persis.
   - Cara mengajak (pertanyaan? tautan? jadwal?).
3. Tunjukkan ringkasan ke pemilik, minta koreksi, simpan.

## Langkah menulis
1. Baca `suara-email.md`. Kalau belum ada, jalankan langkah belajar dulu.
2. Tulis draf: 1 tujuan per email, ≤120 kata kecuali diminta, subjek ≤7 kata.
3. Buat draf di Gmail (bukan kirim) atau simpan di `email/AAAA-BB-HH-topik.md`.
4. Laporkan: jumlah draf, penerima, dan bagian `[ISI: ...]` yang perlu dilengkapi.
