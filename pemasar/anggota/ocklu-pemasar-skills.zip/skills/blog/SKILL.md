---
name: blog
description: Tulis artikel blog SEO dalam gaya merek pemilik. Pakai saat diminta "tulis blog", "artikel", atau dipanggil oleh skill ulang-konten.
---

# Blog
- Baca `CLAUDE.md` dan contoh di `konten/contoh-blog/` kalau ada; tiru struktur & nadanya.
- Struktur: judul ≤60 karakter memuat kata kunci utama; pembuka 2-3 kalimat yang menjawab langsung; 3-5 subjudul H2; poin konkret; penutup + 1 ajakan.
- 600-1.000 kata kecuali diminta lain. Tingkat baca sederhana (kelas 5-8).
- Tambahkan di atas: `kata_kunci:`, `deskripsi_meta:` (≤155 karakter).
- Jangan mengarang statistik. Simpan ke `konten/AAAA-BB-HH-slug.md`.
