---
name: produk-ke-iklan
description: Buat paket iklan video gaya UGC dari foto produk - profil pembeli, brief aktor AI, naskah 15-30 detik, dan daftar shot - dengan label konten AI wajib. Pakai saat diminta "iklan UGC", "video iklan produk", atau "product to ad".
---

# Produk ke Iklan (UGC)

## Aturan keras
- Output WAJIB memuat label: **"Konten ini dibuat dengan AI"** (teks di video + keterangan posting). Meta & TikTok mewajibkan penandaan konten AI realistis.
- Dilarang testimoni palsu: aktor tidak boleh mengaku "sudah pakai 3 bulan", tidak boleh angka hasil/kesehatan yang tidak terbukti, tidak boleh meniru orang nyata/selebriti.

## Langkah
1. Minta: foto produk, nama & 1 kalimat manfaat, target pembeli, nada (santai/semangat/tenang), ajakan akhir.
2. Profil pembeli → brief aktor (usia, gaya, latar) yang cocok — tokoh fiktif.
3. Naskah 15-30 detik: kait 0-3 dtk → masalah → produk → 1 manfaat yang bisa dibuktikan → ajakan. Bahasa lisan.
4. Daftar 3-5 shot (pegang produk, pakai, close-up, ajakan) + teks layar.
5. Kalau ada konektor video (mis. Higgsfield), buat gambar aktor memegang produk lalu videonya; kalau tidak, simpan paket prompt.
6. Simpan ke `aset/iklan-slug.md` dengan label AI di baris pertama.
