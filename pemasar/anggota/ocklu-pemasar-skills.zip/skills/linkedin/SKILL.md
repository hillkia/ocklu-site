---
name: linkedin
description: Tulis post LinkedIn dalam gaya merek pemilik. Pakai saat diminta "post LinkedIn" atau dipanggil oleh skill ulang-konten.
---

# LinkedIn
- Kalimat pertama ≤12 kata yang membuat orang klik "lihat selengkapnya".
- Kalimat pendek, satu ide per baris, 120-250 kata, tanpa jargon.
- Tutup dengan pertanyaan untuk memancing komentar. Maks 3 tagar.
- Simpan ke `sosmed/AAAA-BB-HH-linkedin-slug.md`.
