# CLAUDE.md — identitas merek (dibaca Claude setiap pesan; jaga tetap PENDEK)

## Bisnis
- Nama: [ISI]
- Jual apa (1 kalimat): [ISI]
- Untuk siapa (1 kalimat): [ISI]
- Tautan utama (toko/WA/situs): [ISI]

## Nada
- Bahasa: [Indonesia santai / formal / campur EN]
- Tingkat baca: sederhana, kalimat pendek, tanpa jargon
- Kata yang SERING kami pakai: [ISI]
- Kata yang TIDAK PERNAH kami pakai: [ISI]

## Aturan
- Email: hanya draf, jangan pernah kirim otomatis.
- Jangan mengarang angka, testimoni, atau klien. Kosong → tulis [ISI: ...].
- Konten AI realistis (gambar orang/video) wajib berlabel "dibuat dengan AI".

## Folder
konten/ (blog) · email/ · sosmed/ · prospek/ · aset/ (gambar & video) · laporan/
