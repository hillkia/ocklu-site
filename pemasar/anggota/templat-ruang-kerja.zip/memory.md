# memory.md — fakta yang harus diingat (tambah sendiri, atau suruh Claude "ingat ini")

## Penawaran aktif
- 

## Hasil yang sudah terbukti (dengan angka & tanggal)
- 

## Keputusan
- 

## Orang penting (pelanggan, mitra)
- 
